<template>
  <v-app>
    <v-app-bar app color="red darken-3" dark>
      <h1>Complementaria</h1>
    </v-app-bar>

    <v-container class="pt-12 mt-12">
      <v-card>
        <v-data-table :items="postres" :headers="headers">
          <template v-slot:item.fat="{ item }">
            <v-chip v-if="item.fat > 0">TIENE GRASAS</v-chip>
            <v-chip v-else>NO TIENE GRASAS</v-chip>
          </template>
          <template v-slot:item.acciones="{ item }">
            <v-btn color="red" dark @click="verDetalle(item)">Ver mas</v-btn>
          </template>
        </v-data-table>
      </v-card>
    </v-container>
    <Dialog
      :productoSeleccionado="productoSeleccionado"
      :open="dialog"
      @manejarVentana="manejarVentana($event)"
    />
  </v-app>
</template>

<script>
import Dialog from "./components/Dialog.vue";
import postres from "./assets/data/postres.json";
import headers from "./assets/data/headers.json";

export default {
  components: {
    Dialog,
  },
  data() {
    return {
      headers,
      postres,
      dialog: false,
      productoSeleccionado: {},
    };
  },
  methods: {
    verDetalle(producto) {
      this.dialog = true;
      this.productoSeleccionado = producto;
      console.log(producto);
    },
    manejarVentana(estado) {
      console.log("Emit", estado)
      this.dialog = estado;
    },
  },
};
</script>

<style scoped></style>

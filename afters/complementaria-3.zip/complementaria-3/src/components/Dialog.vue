<template>
  <v-dialog v-model="open" @click:outside="$emit('manejarVentana', false)">
    <v-card>
      <v-card-title>
        <h1>{{ productoSeleccionado.name }}</h1>
      </v-card-title>
      <v-card-text>
        <p>Calorias: {{ productoSeleccionado.calories }}</p>
        <p>Grasas: {{ productoSeleccionado.fat }}</p>
        <p>Carbohidratos: {{ productoSeleccionado.carbs }}</p>
        <p>Proteinas: {{ productoSeleccionado.protein }}</p>
        <p>Hierro: {{ productoSeleccionado.iron }}</p>
      </v-card-text>
    </v-card>
  </v-dialog>
</template>

<script>
export default {
  props: {
    productoSeleccionado: Object,
    open: Boolean,
  },
};
</script>

<style lang="scss" scoped></style>
